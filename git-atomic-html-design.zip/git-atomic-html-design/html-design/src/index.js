import React from 'react';
import ReactDOM from 'react-dom';
import './styles.css';

const App = function(){
	return (
      <div>
        <h1 className="main-heading-tag">Cartoon Network</h1>
        <input className="input-field" />
      	<input type = "button" value= " Search" className="home-button" />
        <h1 className="sub-heading-sub-tag">Click on the video to add to the cart</h1>

      	<img src="src/cn.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn2.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn3.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn4.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn5.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn6.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn7.jpg" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn8.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn9.jpg" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn.png" alt="power puff girls"  className="image-tag"/>
      	<img src="src/cn2.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn3.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn4.png" alt="power puff girls"className="image-tag"/>
      	<img src="src/cn5.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn6.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn7.jpg" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn8.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn9.jpg" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn2.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn3.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn4.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn5.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn6.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn7.jpg" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn8.png" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn9.jpg" alt="power puff girls" className="image-tag"/>
      	<img src="src/cn4.png" alt="power puff girls" className="image-tag"/>
      	
      	   
      	<video src="src/pass-countdown.ogg" className="video-tag" width="170" height="85" controls>
	        <p>If you are reading this, it is because your browser does
	         not support the HTML5 video element.</p>
        </video>
        
        <a href = "" className="anchor-tag">Watch this video</a>

        <p>
	       Cartoon Network is home to your favourite cartoons 
	       with hundreds of free online games for kids.
	       Play games online with Cartoon Network characters 
	       from Adventure Time, Gumball, Ben 10, Regular Show, 
	       The Powerpuff Girls, We Bare Bears, Teen Titans, 
	       Steven Universe, Uncle Grandpa and many more. 
	       Save the Candy Kingdom with Finn and Jake or 
	       hang out with Gumball. There’s adventure games, 
	       puzzle games, action, activity and sports games 
	       for you to play on Cartoon Network online,
	        where the fun never stops.
        </p>

        </div>
	       );
}

ReactDOM.render(<App />, document.querySelector('.container'));